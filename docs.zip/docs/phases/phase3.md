# Phase 5: Albums (2 days)

## Rails
### Models

### Controllers

### Views

## Flux
### Views (React Components)

### Stores

### Actions

## Gems/Libraries

# Phase 4: Styling of Images (1 day)

## Rails
### Models

### Controllers

### Views

## Flux
### Views (React Components)

### Stores

### Actions

## Gems/Libraries
* react-quill (npm)
